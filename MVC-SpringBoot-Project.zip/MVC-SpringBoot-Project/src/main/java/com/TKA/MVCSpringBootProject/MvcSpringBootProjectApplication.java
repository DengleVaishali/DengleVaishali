package com.TKA.MVCSpringBootProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcSpringBootProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcSpringBootProjectApplication.class, args);
	}

}
